#include <iostream>

using namespace std;

int main()
{
    int n = 20;
    cout << hex << n;
}

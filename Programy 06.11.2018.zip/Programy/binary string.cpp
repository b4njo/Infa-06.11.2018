#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    string input;
    int sum=0;

    cin >> input;

    for(int i=0; i<input.size(); i++)
    {
        if(input[i]=='1')
            sum+=pow(2, input.size()-1-i);
    }
    cout << sum;
}

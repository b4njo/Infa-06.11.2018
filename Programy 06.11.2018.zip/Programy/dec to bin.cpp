#include <iostream>
#include <stack>

using namespace std;

int main()
{
    int r;
    stack <int> stos;
    int dec;
    cin >> dec;

    while(dec > 0)
    {
        r=dec%2;
        stos.push(r);
        dec/=2;
    }

    while(!stos.empty())
    {
        cout << stos.top();
        stos.pop();
    }
    return 0;
}
